<footer class="footer footer-transparent footer-light navbar-shadow">
 <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2 container center-layout"><span
   class="float-md-left d-block d-md-inline-block">Copyright &copy; 2019 <a class="text-bold-800 grey darken-2"
    href="https://1.envato.market/modern_admin" target="_blank">PIXINVENT</a></span><span
   class="float-md-right d-none d-lg-block">Hand-crafted & Made with<i class="ft-heart pink"></i><span
    id="scroll-top"></span></span></p>
</footer>
<!-- END: Footer-->


<!-- BEGIN: Vendor JS-->
<script src="admin/app-assets/vendors/js/vendors.min.js"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="admin/app-assets/vendors/js/ui/jquery.sticky.js"></script>
<script src="admin/app-assets/vendors/js/charts/chartist.min.js"></script>
<script src="admin/app-assets/vendors/js/charts/chartist-plugin-tooltip.min.js"></script>
<script src="admin/app-assets/vendors/js/charts/raphael-min.js"></script>
<script src="admin/app-assets/vendors/js/charts/morris.min.js"></script>
<script src="admin/app-assets/vendors/js/timeline/horizontal-timeline.js"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="admin/app-assets/js/core/app-menu.js"></script>
<script src="admin/app-assets/js/core/app.js"></script>
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
<script src="admin/app-assets/js/scripts/pages/dashboard-ecommerce.js"></script>
<!-- END: Page JS-->

</body>
<!-- END: Body-->

</html>